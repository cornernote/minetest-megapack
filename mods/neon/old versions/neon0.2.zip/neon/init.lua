-- A
	minetest.register_node("neon:A", {
	description = "Neon light A",
	tile_images = {"neon_a.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	light_source = 10,
	})
	-- B
	minetest.register_node("neon:B", {
	description = "Neon light B",
	tile_images = {"neon_b.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	light_source = 10,
	})
	-- C
	minetest.register_node("neon:C", {
	description = "Neon light C",
	tile_images = {"neon_c.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	light_source = 10,
	})
	-- D
	minetest.register_node("neon:D", {
	description = "Neon light D",
	tile_images = {"neon_d.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	light_source = 10,
	})
	-- E
	minetest.register_node("neon:E", {
	description = "Neon light E",
	tile_images = {"neon_e.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	light_source = 10,
	})