-- A
	minetest.register_node("neon:A", {
	description = "Neon light A",
	tile_images = {"neon_a.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_a.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- B
	minetest.register_node("neon:B", {
	description = "Neon light B",
	tile_images = {"neon_b.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_b.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- C
	minetest.register_node("neon:C", {
	description = "Neon light C",
	tile_images = {"neon_c.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_c.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- D
	minetest.register_node("neon:D", {
	description = "Neon light D",
	tile_images = {"neon_d.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_d.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- E
	minetest.register_node("neon:E", {
	description = "Neon light E",
	tile_images = {"neon_e.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_e.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- F
	minetest.register_node("neon:F", {
	description = "Neon light F",
	tile_images = {"neon_f.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_f.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- G
	minetest.register_node("neon:G", {
	description = "Neon light G",
	tile_images = {"neon_g.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_g.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- H
	minetest.register_node("neon:H", {
	description = "Neon light H",
	tile_images = {"neon_h.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_h.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- I
	minetest.register_node("neon:I", {
	description = "Neon light I",
	tile_images = {"neon_i.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_i.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- J
	minetest.register_node("neon:J", {
	description = "Neon light J",
	tile_images = {"neon_j.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_j.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- K
	minetest.register_node("neon:K", {
	description = "Neon light K",
	tile_images = {"neon_k.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_k.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- L
	minetest.register_node("neon:L", {
	description = "Neon light L",
	tile_images = {"neon_l.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_l.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- M
	minetest.register_node("neon:M", {
	description = "Neon light M",
	tile_images = {"neon_m.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_m.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- N
	minetest.register_node("neon:N", {
	description = "Neon light N",
	tile_images = {"neon_n.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_n.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- O
	minetest.register_node("neon:O", {
	description = "Neon light O",
	tile_images = {"neon_o.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_o.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- P
	minetest.register_node("neon:P", {
	description = "Neon light P",
	tile_images = {"neon_p.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_p.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- Q
	minetest.register_node("neon:Q", {
	description = "Neon light Q",
	tile_images = {"neon_q.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_q.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- R
	minetest.register_node("neon:R", {
	description = "Neon light R",
	tile_images = {"neon_r.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_r.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- S
	minetest.register_node("neon:S", {
	description = "Neon light S",
	tile_images = {"neon_s.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_s.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- T
	minetest.register_node("neon:T", {
	description = "Neon light T",
	tile_images = {"neon_t.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_t.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- U
	minetest.register_node("neon:U", {
	description = "Neon light U",
	tile_images = {"neon_u.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_u.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- V
	minetest.register_node("neon:V", {
	description = "Neon light V",
	tile_images = {"neon_v.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_v.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- W
	minetest.register_node("neon:W", {
	description = "Neon light W",
	tile_images = {"neon_w.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_w.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- X
	minetest.register_node("neon:X", {
	description = "Neon light X",
	tile_images = {"neon_x.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_x.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- Y
	minetest.register_node("neon:Y", {
	description = "Neon light Y",
	tile_images = {"neon_y.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_y.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- Z
	minetest.register_node("neon:Z", {
	description = "Neon light Z",
	tile_images = {"neon_z.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_z.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 0
	minetest.register_node("neon:0", {
	description = "Neon light 0",
	tile_images = {"neon_0.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_0.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 1
	minetest.register_node("neon:1", {
	description = "Neon light 1",
	tile_images = {"neon_1.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_1.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 2
	minetest.register_node("neon:2", {
	description = "Neon light 2",
	tile_images = {"neon_2.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_2.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 3
	minetest.register_node("neon:3", {
	description = "Neon light 3",
	tile_images = {"neon_3.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_3.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 4
	minetest.register_node("neon:4", {
	description = "Neon light 4",
	tile_images = {"neon_4.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_4.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 5
	minetest.register_node("neon:5", {
	description = "Neon light 5",
	tile_images = {"neon_5.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_5.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 6
	minetest.register_node("neon:6", {
	description = "Neon light 6",
	tile_images = {"neon_6.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_6.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 7
	minetest.register_node("neon:7", {
	description = "Neon light 7",
	tile_images = {"neon_7.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_7.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 8
	minetest.register_node("neon:8", {
	description = "Neon light 8",
	tile_images = {"neon_8.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_8.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})
	-- 9
	minetest.register_node("neon:9", {
	description = "Neon light 9",
	tile_images = {"neon_9.png"},
	drawtype = "signlike",
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	groups = {snappy=2,cracky=3,oddly_breakable_by_hand=3},
	inventory_image = "neon_9.png",
	light_source = 10,
	selection_box = {
		type = "wallmounted",
	},
	})